# Gestão de Tarefas (Task Manager)

Neste documento, descreve-se o enunciado do projeto a desenvolver na edição 2023 da unidade curricular _"Algoritmos e Técnicas de Programação"_.

## Descrição do Projeto:

Neste projeto, estás responsável por desenvolver um sistema de gestão de tarefas em Python, o qual permitirá aos utilizadores criar, atualizar, organizar e acompanhar as suas tarefas diárias, semanais e mensais. O sistema também deve oferecer funcionalidades de priorização, notificação, relatórios sobre o progresso das tarefas e um dashboard estatístico (mostrando gráficos ilustrativos sobre a execução das tarefas, o seu tipo, etc).

## Requisitos do Sistema:

Criação de Tarefas: Os utilizadores devem poder criar tarefas especificando um título, descrição, data de vencimento, prioridade e categoria, por exemplo, trabalho, estudo, pessoal, e outras (pensa num conjunto de categorias interessante e prevê na aplicação a possibilidade de o expandir).

Atualização de Tarefas: Os utilizadores devem poder atualizar as informações das tarefas, como a data de vencimento, descrição, prioridade e categoria.

Organização de Tarefas: O sistema deve permitir que os utilizadores organizem as suas tarefas em diferentes categorias e visualizem as tarefas por categoria.

Priorização: Os utilizadores devem poder definir a prioridade das suas tarefas, e o sistema deve permitir que as tarefas sejam classificadas por ordem de prioridade.

Relatórios de Progresso: Os utilizadores devem poder gerar relatórios que mostrem o progresso das suas tarefas, incluindo tarefas concluídas, pendentes e atrasadas.

Dashboard gráfico: O sistema deve mostrar gráficos que mostrem o progresso das tarefas, a sua distribuição por categorias, a sua distribuição por prioridade e a sua distribuição pelos meses do ano.

## Requisitos Técnicos:

O sistema deve ser implementado em Python.

Utilize estruturas de dados apropriadas para armazenar a informação sobre as tarefas, como dicionários, listas ou listas de dicionários.

Desenvolva uma interface de linha de comando (CLI) e uma interface gráfica para interagir com o sistema.

Use bibliotecas Python relevantes para funcionalidades como gráficos (por exemplo, a biblioteca `matplotlib` que já tem sido usada nas aulas).

Implemente um mecanismo de armazenamento persistente para guardar as tarefas, por exemplo um ficheiro JSON.

## Linha de Comando:

Um utilizador da interface de linha de comandos deve poder executar as seguintes operações:

- Imprimir uma mensagem de `help` com os comandos disponíveis;

- Criar Tarefa: Dada a informação de uma tarefa, o sistema deve criar uma nova tarefa com essa informação;

- Consultar Tarefa: Dado um identificador de uma tarefa, o sistema deve imprimir a informação dessa tarefa, de forma organizada;

- Consultar Tarefas: Listar as tarefas contidas no sistema. Deves implementar várias versões desta funcionalidade, usando mecanismos de ordenação e/ou filtros que aches pertinentes;

- Eliminar Tarefa: Dado o identificar de uma tarefa, o sistema deve eliminar a tarefa correspondente.


## Entrega do Projeto:

Na entrega do projeto deverás entregar:
* Relatório técnico em LaTex de acordo com o modelo fornecido;
* O código-fonte do sistema em Python;
* A documentação detalhada que explique como usar o sistema (pode estar incluída no relatório);
* Exemplos de execução do sistema (podem estar incluídos no relatório).

Este projeto permitirá que pratiques a criação de um sistema de informações útil para organização pessoal ou profissional. Certifica-te de seguir as melhores práticas de desenvolvimento de software e planeia o teu tempo adequadamente para a conclusão do projeto. Boa sorte!





